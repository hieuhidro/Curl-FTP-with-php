require(['jquery'],
    function ($) {
        'use strict';
        $(document).ready(function () {
            alert("sdfsdf");
        });
        return Component.extend({});
    });