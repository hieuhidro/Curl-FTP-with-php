<?php
namespace Forix\Hello\Block;
use \Magento\Framework\View\Element\Template;

class Hello extends Template
{

}