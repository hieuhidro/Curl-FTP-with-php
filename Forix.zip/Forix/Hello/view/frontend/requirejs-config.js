var config = {
    map: {
        "*": {
            hello: "Forix_Hello/js/hello"
        }
    },
};